# Angular 2 Udemy course 

episode: Components

## Description
This repository is my follow up to udemy angular 2 course

## Usage
Follow the following steps and you're good to go! Important: Typescript 
and npm has to be installed on your machine!

1: Base settings
```
https://github.com/mschwarzmueller/angular-2-beta-boilerplate
```
2: Install packages
```
npm install
```
3: Start server (includes auto refreshing) and gulp watcher
```
npm start
```
